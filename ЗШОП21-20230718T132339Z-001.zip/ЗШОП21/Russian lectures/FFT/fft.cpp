// Created by Nikolay Budin

#ifdef DEBUG
#  define _GLIBCXX_DEBUG
#endif
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#define ff first
#define ss second
#define szof(x) ((int)x.size())
#ifndef LOCAL
#  define cerr __get_ce
#endif

using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef unsigned long long ull;

using namespace __gnu_pbds;
template <typename T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template <typename K, typename V> using ordered_map = tree<K, V, less<K>, rb_tree_tag, tree_order_statistics_node_update>;

int const INF = (int)1e9 + 1e3;
ll const INFL = (ll)1e18 + 1e6;
#ifdef LOCAL
	mt19937 tw(9450189);
#else
	mt19937 tw(chrono::high_resolution_clock::now().time_since_epoch().count());
#endif
uniform_int_distribution<ll> ll_distr;
ll rnd(ll a, ll b) { return ll_distr(tw) % (b - a + 1) + a; }

const double PI = atan2(0, -1);
const int bp = 20;
const int sz = 1 << bp;
complex<double> arra[sz], arrb[sz];
complex<double> roots[sz];
int perm[sz];

void init_fft() {
	for (int i = 0; i < sz; ++i) {
		roots[i] = {cos(PI * 2 * i / sz), sin(PI * 2 * i / sz)};
	}
	for (int i = 1; i < sz; ++i) {
		perm[i] = (perm[i >> 1] >> 1) | ((i & 1) << (bp - 1));
	}
}

void fft(complex<double> arr[]) {
	for (int i = 0; i < sz; ++i) {
		if (i < perm[i]) {
			swap(arr[i], arr[perm[i]]);
		}
	}

	for (int i = 1, root_shift = sz / 2; i < sz; i *= 2, root_shift /= 2) {
		for (int j = 0; j < sz; j += i * 2) {
			for (int k = 0, root_pos = 0; k < i; ++k, root_pos += root_shift) {
				auto val1 = arr[j + i + k] * roots[root_pos];
				arr[j + i + k] = arr[j + k] - val1;
				arr[j + k] += val1;
			}
		}
	}
}

vector<int> mult(vector<int> a, vector<int> b) {
	fill(arra, arra + sz, 0);
	for (int i = 0; i < szof(a); ++i) {
		arra[i] = {a[i], 0};
	}
	fft(arra);

	fill(arrb, arrb + sz, 0);
	for (int i = 0; i < szof(b); ++i) {
		arrb[i] = {b[i], 0};
	}
	fft(arrb);

	for (int i = 0; i < sz; ++i) {
		arra[i] *= arrb[i];
	}

	fft(arra);

	reverse(arra + 1, arra + sz);
	vector<int> ret;
	// C * C * n <= 1e9
	for (int i = 0; i < sz; ++i) {
		ret.push_back(round(arra[i].real() / sz));
	}

	while (szof(ret) && ret.back() == 0) {
		ret.pop_back();
	}

	return ret;
}

void solve() {
	init_fft();

	vector<int> a = {1, 2, 3};
	vector<int> b = {1, 2, 1};
	auto res = mult(a, b);
	for (int num : res) {
		cerr << num << " ";
	}
	cerr << endl;
}


int main() {
#ifdef LOCAL
	auto start_time = clock();
	cerr << setprecision(3) << fixed;
#endif
	cout << setprecision(15) << fixed;
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int test_count = 1;
	// cin >> test_count;
	for (int test = 1; test <= test_count; ++test) {
		solve();
	}

#ifdef LOCAL
	auto end_time = clock();
	cerr << "Execution time: " << (end_time - start_time) * (int)1e3 / CLOCKS_PER_SEC << " ms\n";
#endif
}