// Created by Nikolay Budin

#ifdef DEBUG
#  define _GLIBCXX_DEBUG
#endif
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#define ff first
#define ss second
#define szof(x) ((int)x.size())
#ifndef LOCAL
#  define cerr __get_ce
#endif

using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef unsigned long long ull;

using namespace __gnu_pbds;
template <typename T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template <typename K, typename V> using ordered_map = tree<K, V, less<K>, rb_tree_tag, tree_order_statistics_node_update>;

int const INF = (int)1e9 + 1e3;
ll const INFL = (ll)1e18 + 1e6;
#ifdef LOCAL
	mt19937 tw(9450189);
#else
	mt19937 tw(chrono::high_resolution_clock::now().time_since_epoch().count());
#endif
uniform_int_distribution<ll> ll_distr;
ll rnd(ll a, ll b) { return ll_distr(tw) % (b - a + 1) + a; }

const int MOD = 998244353;

void add(int& a, int b) {
	a += b;
	if (a >= MOD) {
		a -= MOD;
	}
}

int sum(int a, int b) {
	add(a, b);
	return a;
}

int mult(int a, int b) {
	return (ll) a * b % MOD;
}

int mpow(int a, int b) {
	int ret = 1;
	while (b) {
		if (b & 1) {
			ret = mult(ret, a);
		}
		a = mult(a, a);
		b /= 2;
	}
	return ret;
}

int inv(int num) {
	return mpow(num, MOD - 2);
}


const int bp = 20;
const int sz = 1 << bp;
const int inv_sz = inv(sz);
int arra[sz], arrb[sz];
int roots[sz];
int perm[sz];

void init_fft() {
	int root;
	for (root = 1; ; ++root) {
		// mpow(root, sz) = 1
		// mpow(root, sz / 2) != 1

		// mpow(root, sz / 2) = -1
		if (mpow(root, sz / 2) == MOD - 1) {
			break;
		}
	}

	roots[0] = 1;
	for (int i = 1; i < sz; ++i) {
		roots[i] = mult(roots[i - 1], root);
		perm[i] = (perm[i >> 1] >> 1) | ((i & 1) << (bp - 1));
	}
}

void fft(int arr[]) {
	for (int i = 0; i < sz; ++i) {
		if (i < perm[i]) {
			swap(arr[i], arr[perm[i]]);
		}
	}

	for (int i = 1, root_shift = sz / 2; i < sz; i *= 2, root_shift /= 2) {
		for (int j = 0; j < sz; j += i * 2) {
			for (int k = 0, root_pos = 0; k < i; ++k, root_pos += root_shift) {
				auto val1 = mult(arr[j + i + k], roots[root_pos]);
				arr[j + i + k] = sum(arr[j + k], MOD - val1);
				add(arr[j + k], val1);
			}
		}
	}
}

vector<int> mult(vector<int> a, vector<int> b) {
	fill(arra, arra + sz, 0);
	for (int i = 0; i < szof(a); ++i) {
		arra[i] = a[i];
	}
	fft(arra);

	fill(arrb, arrb + sz, 0);
	for (int i = 0; i < szof(b); ++i) {
		arrb[i] = b[i];
	}
	fft(arrb);

	for (int i = 0; i < sz; ++i) {
		arra[i] =  mult(arra[i], arrb[i]);
	}

	fft(arra);

	reverse(arra + 1, arra + sz);
	vector<int> ret;
	// C * C * n <= 1e9
	for (int i = 0; i < sz; ++i) {
		ret.push_back(mult(arra[i], inv_sz));
	}

	while (szof(ret) && ret.back() == 0) {
		ret.pop_back();
	}

	return ret;
}

void solve() {
	init_fft();

	string s, t;
	cin >> s >> t;

	vector<int> a;
	vector<int> b;

	for (char c : s) {
		a.push_back(c - '0');
	}

	reverse(a.begin(), a.end());

	for (char c : t) {
		b.push_back(c - '0');
	}

	reverse(b.begin(), b.end());

	auto res = mult(a, b);
	
	ll carry = 0;
	for (int i = 0; i < szof(res) || carry; ++i) {
		if (i == szof(res)) {
			res.push_back(0);
		}
		carry += res[i];
		res[i] = carry % 10;
		carry /= 10;
	}

	reverse(res.begin(), res.end());
	for (int d : res) {
		cerr << d;
	}
	cerr << endl;
}


int main() {
#ifdef LOCAL
	auto start_time = clock();
	cerr << setprecision(3) << fixed;
#endif
	cout << setprecision(15) << fixed;
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int test_count = 1;
	// cin >> test_count;
	for (int test = 1; test <= test_count; ++test) {
		solve();
	}

#ifdef LOCAL
	auto end_time = clock();
	cerr << "Execution time: " << (end_time - start_time) * (int)1e3 / CLOCKS_PER_SEC << " ms\n";
#endif
}